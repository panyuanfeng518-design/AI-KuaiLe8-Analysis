# AI 快乐8自动分析系统（iPhone PWA）

## 部署
- Render 类型：Web Service
- Build Command：`npm install`
- Start Command：`npm start`
- Runtime：Node 18 或更新版本

## 说明
- 当前版本包含手机网页、PWA 主屏幕配置、IndexedDB 本机保存、CSV/TXT 导入导出和随机选十实验号码。
- `/api/history` 当前是占位接口；自动抓取数据源尚未完成验证。请先手动导入历史数据。
- 历史频率、遗漏和其他方法不能证明未来中奖优势。严格样本外回测、多重比较校正和独立复现尚未实现。
- 用户数据保存在当前设备浏览器，建议定期导出备份。
