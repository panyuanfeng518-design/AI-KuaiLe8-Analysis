const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, "public");

app.disable("x-powered-by");
app.use(express.json({ limit: "5mb" }));
app.use(express.static(PUBLIC_DIR, { extensions: ["html"] }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "AI 快乐8自动分析系统", version: "1.0.0" });
});

// 历史数据接口：当前先提供稳定的导入入口。
// 自动抓取不同彩票网站的数据结构可能变化，完成来源验证后再启用定时抓取。
app.get("/api/history", (_req, res) => {
  res.json({
    ok: true,
    source: "manual-import",
    message: "请先通过页面导入官方历史开奖 CSV/TXT 文件；自动抓取源尚未验证。",
    draws: []
  });
});

app.get("*", (_req, res) => {
  const index = path.join(PUBLIC_DIR, "index.html");
  if (fs.existsSync(index)) return res.sendFile(index);
  res.status(404).send("未找到应用页面");
});

app.listen(PORT, () => {
  console.log(`AI 快乐8自动分析系统运行于端口 ${PORT}`);
});
