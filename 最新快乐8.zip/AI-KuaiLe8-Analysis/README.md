# AI 快乐8自动分析系统（iPhone PWA）升级版

## 本次升级
- 老彩民综合选号实验模式：近期冷热、遗漏、区间、奇偶、大小等指标进行有限权重抽样。
- 保留随机对照模式。
- 手动输入期号与20个开奖号码，校验后保存到 IndexedDB。
- 相同期号重复录入会跳过。
- 生成号码支持逐注复制和全部复制。
- 支持 CSV/TXT 导入与 CSV 备份导出。

## 部署
沿用原项目 Render 配置。Build Command 与 Start Command 不变：
- Build: `unzip -o AI-KuaiLe8-Analysis-iPhone-PWA.zip && cd AI-KuaiLe8-Analysis && npm install`
- Start: `cd AI-KuaiLe8-Analysis && npm start`

## 重要说明
综合选号仅为待验证的统计实验，不是已证实的预测方法。当前页面尚未实现严格样本外回测，也不会声称优于随机。开奖历史保存在当前设备浏览器 IndexedDB，升级前建议先导出 CSV 备份。
